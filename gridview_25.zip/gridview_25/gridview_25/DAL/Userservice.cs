﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using gridview_25.BAL;
using System.Configuration;

namespace gridview_25.DAL
{
    public class Userservice
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        public bool adduser(Userobject uo)

        {
            cmd = new SqlCommand("adduser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@uname", uo.uname);
            cmd.Parameters.AddWithValue("@ugender", uo.ugender);
            cmd.Parameters.AddWithValue("@udob", uo.udob);
            cmd.Parameters.AddWithValue("@usid",uo.usid);
            cmd.Parameters.AddWithValue("@ucid",uo.ucid);
            cmd.Parameters.AddWithValue("@uhobby",uo.uhobby);
            cmd.Parameters.AddWithValue("@uphoto", uo.uphoto);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return true;
        }

        public DataTable GetUserDetail()
        {
            cmd = new SqlCommand("GetUserDetail", con);
            cmd.CommandType = CommandType.StoredProcedure;
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            return dt;
        }




    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using gridview_25.BAL;
using System.Data.SqlClient;
using System.IO;


namespace gridview_25
{
    public partial class Userregister : System.Web.UI.Page
    {
        Locationobject lo = new Locationobject();
        Userobject uo = new Userobject();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillstate();
                filldata();
            }
        }

        private void filldata()
        {
            GridView1.DataSource = uo.GetUserDetail();
            GridView1.DataBind();
        }

        

        private void fillstate()
        {
            Drpstate.DataSource = lo.GetState();
            Drpstate.DataTextField = "statename";
            Drpstate.DataValueField = "stateid";
            Drpstate.DataBind();
            Drpstate.Items.Insert(0, "select state"); 
        }

        private void fillcity()
        {
            int sid = Convert.ToInt32(Drpstate.SelectedItem.Value);
            Drpcity.DataSource = lo.GetCitybyState(sid);
            Drpcity.DataTextField = "cityname";
            Drpcity.DataValueField = "cityid";
            Drpcity.DataBind();
            Drpcity.Items.Insert(0, "select city");
        }


        protected void Drpstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            fillcity();
        }

        protected void Btnsave_Click(object sender, EventArgs e)
        {
            string pic = Path.GetExtension(Fpupload.PostedFile.FileName);
            if (pic.ToLower() == ".png" || pic.ToLower() == ".jpg" || pic.ToLower() == ".jpeg")
            {
                uo.uphoto = "~//" + Fpupload.PostedFile.FileName;
                Fpupload.SaveAs(MapPath(uo.uphoto));
                uo.uname = txtuname.Text;
                uo.ugender = Rdogender.SelectedItem.Text;
                uo.udob = Convert.ToDateTime(txtDob.Text);
                uo.usid = Convert.ToInt32(Drpstate.SelectedItem.Value);
                uo.ucid = Convert.ToInt32(Drpcity.SelectedItem.Value);
                foreach (ListItem item in chkhobbie.Items)
                {
                    if (item.Selected)
                    {
                        uo.uhobby += item.Text + ",";
                    }
                }
                uo.uhobby = uo.uhobby.TrimEnd(',');

                bool ou = uo.adduser();
                if (ou)
                {
                    Response.Write("User Info Saved");
                }
                else
                {
                    Response.Write("failed !!!");
                }
                filldata();


            }
            else {
                Response.Write("please enter a file jpg , png , jpeg format");
            }
        }

        protected void Btncancle_Click(object sender, EventArgs e)
        {
            Drpstate.ClearSelection();
            Drpcity.ClearSelection();
            txtuname.Text = string.Empty;
            txtDob.Text = string.Empty;
            Rdogender.ClearSelection();
            chkhobbie.ClearSelection();

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            filldata();
                
        }
    }
}
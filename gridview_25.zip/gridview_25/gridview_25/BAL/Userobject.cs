﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gridview_25.DAL;
using System.Data;

namespace gridview_25.BAL
{
    
    public class Userobject
    {
        Userservice us = new Userservice();

        public int uid { get; set; }
        public string uname { get; set; }
        public string ugender { get; set; }
        public DateTime udob { get; set; }
        public int usid { get; set; }
        public int ucid { get; set; }
        public string uhobby { get; set; }
        public string uphoto { get; set; }


        public bool adduser()
        {
            return us.adduser(this);
        }
        public DataTable GetUserDetail()
        {
            return us.GetUserDetail();
        }
    }
}
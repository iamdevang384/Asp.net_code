﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using gridview_25.DAL;
using System.Data;
using System.Data.SqlClient;

namespace gridview_25.BAL
{
    public class Locationobject
    {
        Locationservice ls = new Locationservice();
         public int stateid { get; set; }
        public string statename { get; set; }
        public int cityid { get; set; }
        public string cityname { get; set; }

        public DataTable GetState()
        {
             return ls.GetState();
        }
        public DataTable GetCitybyState(int sid)
        {
            return ls.GetCitybyState(sid);
        }
    }
}
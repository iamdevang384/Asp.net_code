﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DhruminiBatchProject.BAL;

namespace DhruminiBatchProject.MyUser
{
    public partial class myprofile : System.Web.UI.Page
    {
        UserObject uo = new UserObject();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillProfileDetails();
            }
        }

        private void FillProfileDetails()
        {
            DataList1.DataSource = uo.GetUserList(Convert.ToInt32(Session["uid"]));
            DataList1.DataBind();
        }

        protected void DataList1_EditCommand(object source, DataListCommandEventArgs e)
        {
            DataList1.EditItemIndex = e.Item.ItemIndex;
            FillProfileDetails();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using DhruminiBatchProject.BAL;

namespace DhruminiBatchProject.DAL.Services
{
    public class UserService
    {
        Gateway gw = new Gateway();
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;


        public bool AddUser(UserObject obj)
        {
            cmd = new SqlCommand("AddUser", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uname", obj.uname);
            cmd.Parameters.AddWithValue("@ugender", obj.ugender);
            cmd.Parameters.AddWithValue("@udob", obj.udob);
            cmd.Parameters.AddWithValue("@uemail", obj.uemail);
            cmd.Parameters.AddWithValue("@upass", obj.upass);
            cmd.Parameters.AddWithValue("@sid", obj.sid);
            cmd.Parameters.AddWithValue("@cid", obj.cid);
            cmd.Parameters.AddWithValue("@uedu", obj.uedu);
            cmd.Parameters.AddWithValue("@uphoto", obj.uphoto);
            gw.con.Open();
            cmd.ExecuteNonQuery();
            gw.con.Close();
            return true;
        }

        public DataTable GetUserList(int uid)
        {
            cmd = new SqlCommand("GetUserList", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uid", uid);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            return dt;

        }

        public bool UpdateUser(UserObject obj)
        {
            cmd = new SqlCommand("UpdateUser", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uid", obj.uid);
            cmd.Parameters.AddWithValue("@uname", obj.uname);
            cmd.Parameters.AddWithValue("@ugender", obj.ugender);
            cmd.Parameters.AddWithValue("@udob", obj.udob);
            cmd.Parameters.AddWithValue("@uemail", obj.uemail);
            cmd.Parameters.AddWithValue("@sid", obj.sid);
            cmd.Parameters.AddWithValue("@cid", obj.cid);
            cmd.Parameters.AddWithValue("@uedu", obj.uedu);
            cmd.Parameters.AddWithValue("@uphoto", obj.uphoto);
            gw.con.Open();
            cmd.ExecuteNonQuery();
            gw.con.Close();
            return true;
        }


        public bool DeleteUser(int uid)
        {
            cmd = new SqlCommand("DeleteUser", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uid", uid);
            gw.con.Open();
            cmd.ExecuteNonQuery();
            gw.con.Close();
            return true;
        }

        
        public bool ManageUser(int uid)
        {
            cmd = new SqlCommand("ManageUser", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uid", uid);
            gw.con.Open();
            cmd.ExecuteNonQuery();
            gw.con.Close();
            return true;
        }

        public DataTable CheckLogin(string uemail,string upass)
        {
            cmd = new SqlCommand("CheckLogin", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@uemail", uemail);
            cmd.Parameters.AddWithValue("@upass", upass);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
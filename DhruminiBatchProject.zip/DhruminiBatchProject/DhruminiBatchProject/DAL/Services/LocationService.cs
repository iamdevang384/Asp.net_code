﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace DhruminiBatchProject.DAL.Services
{
    public class LocationService
    {
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;
        Gateway gw = new Gateway();

        public DataTable GetStates()
        {
            cmd = new SqlCommand("GetStates", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable GetCityByState(int id)
        {
            cmd = new SqlCommand("GetCityByState", gw.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }
}
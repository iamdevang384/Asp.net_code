﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DhruminiBatchProject.BAL;

namespace DhruminiBatchProject
{
    public partial class Registration : System.Web.UI.Page
    {
        private LocationObject obj = new LocationObject();
        UserObject user = new UserObject();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillState();

            }
        }

        private void FillState()
        {
            drpState.DataSource = obj.GetStates();
            drpState.DataTextField = "SNAME";
            drpState.DataValueField = "Id";
            drpState.DataBind();
            drpState.Items.Insert(0, "Select State");
        }

        protected void drpState_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillCity();
        }

        private void FillCity()
        {

            if (drpState.SelectedItem.Value != "Select State")
            {
                int id = Convert.ToInt32(drpState.SelectedItem.Value);
                drpCity.DataSource = obj.GetCityByState(id);
                drpCity.DataTextField = "cname";
                drpCity.DataValueField = "Id";
                drpCity.DataBind();
                drpCity.Items.Insert(0, "Select City");
            }
            else
            {
                drpCity.Items.Insert(0, "Select City");
            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            user.uname = txtuname.Text;
            user.ugender = rdoGender.SelectedItem.Text;
            user.udob = calDob.SelectedDate;
            user.uemail = txtemail.Text;
            user.upass = txtpass.Text;
            user.sid = Convert.ToInt32(drpState.SelectedItem.Value);
            user.cid = Convert.ToInt32(drpCity.SelectedItem.Value);


            foreach (ListItem item in CheckBoxList1.Items)
            {
                if (item.Selected)
                {
                    user.uedu += item.Text + ",";
                }
            }

            user.uphoto = "~/UserImages/" + FileUpload1.PostedFile.FileName;
            FileUpload1.SaveAs(Server.MapPath(user.uphoto));

          bool op = user.AddUser();

          if (op)
          {
              Response.Write("user saved");
          }
          else
          {
              Response.Write("error!!!!");
          }

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using DhruminiBatchProject.DAL.Services;

namespace DhruminiBatchProject.BAL
{
    public class LocationObject
    {
        private LocationService ls = new LocationService();

        public DataTable GetStates()
        {
            return ls.GetStates();
        }

        public DataTable GetCityByState(int id)
        {
            return ls.GetCityByState(id);
        }
    }
}
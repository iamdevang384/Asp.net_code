﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DhruminiBatchProject.DAL.Services;
using System.Data;

namespace DhruminiBatchProject.BAL
{
    public class UserObject
    {
        UserService obj = new UserService();

        public int uid { get; set; }
        public string uname { get; set; }
        public string ugender { get; set; }
        public DateTime udob { get; set; }
        public string uemail { get; set; }
        public string upass { get; set; }
        public string uedu { get; set; }
        public int sid { get; set; }
        public int cid { get; set; }
        public string uphoto { get; set; }
        public bool isActive { get; set; }
        public DateTime regdate { get; set; }

        public bool AddUser()
        {
            return obj.AddUser(this);
        }

        public bool UpdateUser()
        {
            return obj.UpdateUser(this);
        }

        public DataTable GetUserList(int uid)
        {
            return obj.GetUserList(uid);
        }

        public bool DeleteUser(int uid)
        {
            return obj.DeleteUser(uid);
        }

        public bool ManageUser(int uid)
        {
            return obj.ManageUser(uid);
        }

        public DataTable CheckLogin(string uemail, string upass)
        {
            return obj.CheckLogin(uemail, upass);
        }
    }
}
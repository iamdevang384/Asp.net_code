﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DhruminiBatchProject.BAL;

namespace DhruminiBatchProject
{
    public partial class UserDetailss : System.Web.UI.Page
    {

        UserObject uo = new UserObject();
        LocationObject obj = new LocationObject();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FillUserList();
            }
        }

        private void FillUserList()
        {
            GridView1.DataSource = uo.GetUserList(0);
            GridView1.DataBind();
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            //ITEM TEMPLATE
            Label lblGender = (Label)GridView1.Rows[e.NewEditIndex].FindControl("Label3");
            Label lblState = (Label)GridView1.Rows[e.NewEditIndex].FindControl("Label6");
            Label lblCity = (Label)GridView1.Rows[e.NewEditIndex].FindControl("Label7");
            Label lblEdu = (Label)GridView1.Rows[e.NewEditIndex].FindControl("Label8");


            GridView1.EditIndex = e.NewEditIndex;
            FillUserList();


            //EDIT ITEM TEMPLATE 
            RadioButtonList rdo = (RadioButtonList)GridView1.Rows[e.NewEditIndex].FindControl("RadioButtonList1");
            foreach (ListItem item in rdo.Items)
            {
                if (item.Text == lblGender.Text)
                {
                    item.Selected = true;
                }
            }


            DropDownList drpState = (DropDownList)GridView1.Rows[e.NewEditIndex].FindControl("DropDownList1");

            drpState.DataSource = obj.GetStates();
            drpState.DataTextField = "SNAME";
            drpState.DataValueField = "Id";
            drpState.DataBind();
            drpState.Items.Insert(0, "Select State");

            foreach (ListItem item in drpState.Items)
            {
                if (item.Text == lblState.Text)
                {
                    item.Selected = true;
                }
            }


            DropDownList drpCity = (DropDownList)GridView1.Rows[e.NewEditIndex].FindControl("DropDownList2");
            int id = Convert.ToInt32(drpState.SelectedItem.Value);
            drpCity.DataSource = obj.GetCityByState(id);
            drpCity.DataTextField = "cname";
            drpCity.DataValueField = "Id";
            drpCity.DataBind();
            drpCity.Items.Insert(0, "Select City");

            foreach (ListItem item in drpCity.Items)
            {
                if (item.Text == lblCity.Text)
                {
                    item.Selected = true;
                }
            }


            CheckBoxList chk = (CheckBoxList)GridView1.Rows[e.NewEditIndex].FindControl("CheckBoxList1");
            foreach (ListItem item in chk.Items)
            {
                if (lblEdu.Text.Contains(item.Text))
                {
                    item.Selected = true;
                }
            }
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            FillUserList();
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList drpState = (DropDownList)GridView1.Rows[GridView1.EditIndex].FindControl("DropDownList1");
            DropDownList drpCity = (DropDownList)GridView1.Rows[GridView1.EditIndex].FindControl("DropDownList2");
            int id = Convert.ToInt32(drpState.SelectedItem.Value);
            drpCity.DataSource = obj.GetCityByState(id);
            drpCity.DataTextField = "cname";
            drpCity.DataValueField = "Id";
            drpCity.DataBind();
            drpCity.Items.Insert(0, "Select City");
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            uo.uid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            uo.uname = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1")).Text;
            uo.ugender = ((RadioButtonList)GridView1.Rows[e.RowIndex].FindControl("RadioButtonList1")).SelectedItem.Text;
            uo.uemail = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2")).Text;
            uo.sid = Convert.ToInt32(((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList1")).SelectedItem.Value);
            uo.cid = Convert.ToInt32(((DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2")).SelectedItem.Value);
            uo.udob = ((Calendar)GridView1.Rows[e.RowIndex].FindControl("Calendar1")).SelectedDate;

            CheckBoxList chk = (CheckBoxList)GridView1.Rows[e.RowIndex].FindControl("CheckBoxList1");
            foreach (ListItem item in chk.Items)
            {
                if (item.Selected)
                {
                    uo.uedu += item.Text + ",";
                }
            }

            Image img = (Image)GridView1.Rows[e.RowIndex].FindControl("Image2");
            FileUpload fp = (FileUpload)GridView1.Rows[e.RowIndex].FindControl("FileUpload1");

            if (fp.HasFile)
            {
                uo.uphoto = "~/UserImages/" + fp.PostedFile.FileName;
                fp.SaveAs(Server.MapPath(uo.uphoto));
                System.IO.File.Delete(Server.MapPath(img.ImageUrl));
            }
            else
            {
                uo.uphoto = img.ImageUrl;
            }

            uo.UpdateUser();
            GridView1.EditIndex = -1;
            FillUserList();
            Response.Write("<script>alert('user info updated');</script>");

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            uo.uid = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value);
            uo.DeleteUser(uo.uid);
            FillUserList();
            Response.Write("<script>alert('user info deleted');</script>");

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            FillUserList();
        }

        protected void chkAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox chkAll = (CheckBox)GridView1.HeaderRow.FindControl("chkAll");
            if (chkAll.Checked)
            {
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    CheckBox chk = (CheckBox)GridView1.Rows[i].FindControl("chk");
                    chk.Checked = true;
                }
            }
            else
            {
                for (int i = 0; i < GridView1.Rows.Count; i++)
                {
                    CheckBox chk = (CheckBox)GridView1.Rows[i].FindControl("chk");
                    chk.Checked = false;
                }

            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                CheckBox chk = (CheckBox)GridView1.Rows[i].FindControl("chk");
                if (chk.Checked)
                {
                    int id = Convert.ToInt32(GridView1.DataKeys[i].Value);
                    uo.DeleteUser(id);
                }
            }
            FillUserList();
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "manage")
            {
                uo.ManageUser(Convert.ToInt32(e.CommandArgument));
            }
            FillUserList();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DhruminiBatchProject.BAL;
using System.Data;

namespace DhruminiBatchProject
{
    public partial class login : System.Web.UI.Page
    {
        UserObject uo = new UserObject();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtemail.Text != "" && txtpass.Text != "")
            {
                try
                {
                  DataTable dt =  uo.CheckLogin(txtemail.Text, txtpass.Text);

                    if (dt.Rows.Count>0)
                    {
                        Session["uid"] = dt.Rows[0][0].ToString();
                        Session["uname"] = dt.Rows[0][1].ToString();
                        Session["uphoto"] = dt.Rows[0][2].ToString();
                        Response.Redirect("~/MyUser/dashboard.aspx");
                    }
                    else
                    {
                        Response.Write("<script>alert('please enter correct login details');</script>");
                    }

                }
                catch (Exception ee)
                {
                    throw ee;
                }
            }
            else
            {
                Response.Write("<script>alert('please enter login details');</script>");
            }
        }
    }
}